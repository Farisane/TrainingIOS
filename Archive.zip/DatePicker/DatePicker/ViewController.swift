//
//  ViewController.swift
//  DatePicker
//
//  Created by Batsa Taqiya on 24/11/17.
//  Copyright © 2017 Batsa Taqiya. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var Label: UILabel!
    @IBOutlet weak var LabelDate: UIDatePicker!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func btnDate(_ sender: Any) {
        let data = DateFormatter()
        data.dateFormat = "dd-MM-yyyy HH:mm:ss"
        let strDate = data.string(from: LabelDate.date)
        
        Label.text = strDate
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

