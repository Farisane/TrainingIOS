//
//  ViewController.swift
//  btnSenter
//
//  Created by Batsa Taqiya on 24/11/17.
//  Copyright © 2017 Batsa Taqiya. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var  lblswitch : UISwitch!
    @IBOutlet weak var lblhidupmati: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
//    func changeSwift(switchState:UISwitch){
//        if lblswitch.isOn{
//            lblhidupmati.text = "Switch Is ON"
//        }
//        else{
//            lblhidupmati.text = "Switch Is OFF"
//        }
//
//    }
    
    @IBAction func btnOnOff(_ sender: Any) {
        if lblswitch.isOn{
            lblhidupmati.text = "Switch Is OFF"
            lblswitch.setOn(false,animated: true)
        }
        else{
            lblhidupmati.text = "Switch Is ON"
            lblswitch.setOn(true, animated: true)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

