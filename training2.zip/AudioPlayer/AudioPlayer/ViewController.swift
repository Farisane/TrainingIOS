//
//  ViewController.swift
//  AudioPlayer
//
//  Created by Batsa Taqiya on 25/11/17.
//  Copyright © 2017 Batsa Taqiya. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    var myAudioPlayer = AVAudioPlayer()

    @IBOutlet weak var Volume: UISlider!
    @IBAction func btnvolume(_ sender: Any) {
        myAudioPlayer.volume = Volume.value
    }
    @IBAction func btnPlay(_ sender: Any) {
        myAudioPlayer.play()
    }
    @IBAction func btnStop(_ sender: Any) {
        myAudioPlayer.stop()
        myAudioPlayer.currentTime = 0
    }
    @IBAction func btnPause(_ sender: Any) {
        myAudioPlayer.pause()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let myFile = Bundle.main.path(forResource: "Foreign", ofType: ".mp3")
        if let myFile = myFile {
            let myFileUrl = NSURL(fileURLWithPath: myFile)
            do{
                try myAudioPlayer = AVAudioPlayer(contentsOf : myFileUrl as URL)
            }catch{
                print("Error")
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

