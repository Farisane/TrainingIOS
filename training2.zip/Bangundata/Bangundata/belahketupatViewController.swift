//
//  belahketupatViewController.swift
//  Bangundata
//
//  Created by Batsa Taqiya on 25/11/17.
//  Copyright © 2017 Batsa Taqiya. All rights reserved.
//

import UIKit

class belahketupatViewController: UIViewController {

    @IBOutlet weak var lblhasilkeliling: UILabel!
    @IBOutlet weak var lblhasilluas: UILabel!
    @IBOutlet weak var lblmasukkansisi: UITextField!
    @IBOutlet weak var lblmasukkanD2: UITextField!
    @IBOutlet weak var lblmasukkanD1: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func btnluas(_ sender: Any) {
        let D1 : Int? = Int(lblmasukkanD1.text!)
        let D2 : Int? = Int(lblmasukkanD2.text!)
        let luas : Int = ((D1! * D2!) / 2)
        lblhasilluas.text = "Hasil Dari Luas = \(luas)"
    }
    
    @IBAction func btnkeliling(_ sender: Any) {
        let sisi : Int? = Int(lblmasukkansisi.text!)
        let keliling : Int = ( 4 * sisi!)
        lblhasilkeliling.text = "Hasil dari Keliling = \(keliling)"
    }
    @IBAction func reset(_ sender: Any) {
        lblmasukkanD1.text = ""
        lblmasukkanD2.text = ""
        lblmasukkansisi.text = ""
        lblhasilkeliling.text = ""
        lblhasilluas.text = ""
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
