//
//  trapesiumViewController.swift
//  Bangundata
//
//  Created by Batsa Taqiya on 25/11/17.
//  Copyright © 2017 Batsa Taqiya. All rights reserved.
//

import UIKit

class trapesiumViewController: UIViewController {

    @IBOutlet weak var lblhasilkeliling: UILabel!
    @IBOutlet weak var lblhasilluas: UILabel!
    @IBOutlet weak var lblmasukkantinggi: UITextField!
    @IBOutlet weak var lblmasukkansisikiri: UITextField!
    @IBOutlet weak var lblmasukkansisikanan: UITextField!
    @IBOutlet weak var lblmasukkanatap: UITextField!
    @IBOutlet weak var lblmasukkanalas: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func btnluas(_ sender: Any) {
        let alas : Int? = Int(lblmasukkanalas.text!)
        let atap : Int? = Int(lblmasukkanatap.text!)
        let tinggi : Int? = Int(lblmasukkantinggi.text!)
        let luas : Int = ((alas! + atap!) * tinggi! / 2)
        lblhasilluas.text = "Luas Dari Trapesium = \(luas)"
    }
    @IBAction func btnkeliling(_ sender: Any) {
        let alas : Int? = Int(lblmasukkanalas.text!)
        let atap : Int? = Int(lblmasukkanatap.text!)
        let siskan : Int? = Int(lblmasukkansisikanan.text!)
        let siskir : Int? = Int(lblmasukkansisikiri.text!)
        let keliling : Int = (alas! + atap! + siskan! + siskir!)
        lblhasilkeliling.text = "Keliling dari Trapesium = \(keliling)"
    }
    @IBAction func reset(_ sender: Any) {
        lblmasukkanalas.text = ""
        lblmasukkanatap.text = ""
        lblmasukkansisikiri.text = ""
        lblmasukkansisikanan.text = ""
        lblmasukkantinggi.text = ""
        lblhasilluas.text = ""
        lblhasilkeliling.text = ""
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
