//
//  segitigaViewController.swift
//  Bangundata
//
//  Created by Batsa Taqiya on 25/11/17.
//  Copyright © 2017 Batsa Taqiya. All rights reserved.
//

import UIKit

class segitigaViewController: UIViewController {

    @IBOutlet weak var lblmasukkansisi: UITextField!
    @IBOutlet weak var lblhasilkeliling: UILabel!
    @IBOutlet weak var lblhasilluas: UILabel!
    @IBOutlet weak var lblmasukkantinggi: UITextField!
    @IBOutlet weak var lblmasukkanalas: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func btnluas(_ sender: Any) {
        let alas : Int? = Int(lblmasukkanalas.text!)
        let tinggi : Int? = Int(lblmasukkantinggi.text!)
        let luas : Int = ((alas! * tinggi!) / 2)
        lblhasilluas.text = "Hasil dari Luas Segitiga = \(luas)"
    }
    @IBAction func btnkeliling(_ sender: Any) {
        let sisi : Int? = Int(lblmasukkansisi.text!)
        let keliling : Int = (3 * sisi!)
        lblhasilkeliling.text = "Hasil dari keliling Segitiga = \(keliling)"
    }
    @IBAction func btnreset(_ sender: Any) {
        lblmasukkanalas.text = ""
        lblmasukkantinggi.text = ""
        lblmasukkansisi.text = ""
        lblhasilluas.text = ""
        lblhasilkeliling.text = ""
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
