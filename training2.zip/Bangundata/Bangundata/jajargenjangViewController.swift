//
//  jajargenjangViewController.swift
//  Bangundata
//
//  Created by Batsa Taqiya on 25/11/17.
//  Copyright © 2017 Batsa Taqiya. All rights reserved.
//

import UIKit

class jajargenjangViewController: UIViewController {

    @IBOutlet weak var lblhasilkeliling: UILabel!
    @IBOutlet weak var lblhasilluas: UILabel!
    @IBOutlet weak var lblmasukkanlebar: UITextField!
    @IBOutlet weak var lblmasukkantinggi: UITextField!
    @IBOutlet weak var lblmasukanalas: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func btnluas(_ sender: Any) {
        let alas : Int? = Int(lblmasukanalas.text!)
        let tinggi : Int? = Int(lblmasukkantinggi.text!)
        let luas : Int = Int(alas! * tinggi!)
        lblhasilluas.text = "Hasil Dari Luas = \(luas)"
    }
    @IBAction func btnkeliling(_ sender: Any) {
        let alas : Int? = Int(lblmasukanalas.text!)
        let lebar : Int? = Int(lblmasukkanlebar.text!)
        let keliling : Int = Int(2 * (alas! + lebar!))
        lblhasilkeliling.text = "Hasil Dari Keliling  = \(keliling)"
    }
    
    @IBAction func btnreset(_ sender: Any) {
        lblmasukanalas.text = ""
        lblmasukkantinggi.text = ""
        lblmasukkanlebar.text = ""
        lblhasilluas.text = ""
        lblhasilkeliling.text = ""
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
