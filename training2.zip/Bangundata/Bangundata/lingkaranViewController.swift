//
//  lingkaranViewController.swift
//  Bangundata
//
//  Created by Batsa Taqiya on 25/11/17.
//  Copyright © 2017 Batsa Taqiya. All rights reserved.
//

import UIKit

class lingkaranViewController: UIViewController {

    @IBOutlet weak var lblkeliling: UILabel!
    @IBOutlet weak var lblluas: UILabel!
    @IBOutlet weak var lbljari: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func btnluas(_ sender: Any) {
        let jari : Int? = Int(lbljari.text!)
        let luas : Int = (jari! * jari! * 22 / 7)
        lblluas.text = "Luas Dari Lingkarang = \(luas)"
    }
    @IBAction func btnkeliling(_ sender: Any) {
        let jari : Int? = Int(lbljari.text!)
        let keliling : Int = (2 * jari! * 22 / 7)
        lblkeliling.text = "Keliling dari Lingkaran = \(keliling)"
    }
    @IBAction func btnreset(_ sender: Any) {
        lbljari.text = ""
        lblkeliling.text = ""
        lblluas.text = ""
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
