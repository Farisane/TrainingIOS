//
//  PersegiViewController.swift
//  Bangundata
//
//  Created by Batsa Taqiya on 25/11/17.
//  Copyright © 2017 Batsa Taqiya. All rights reserved.
//

import UIKit

class PersegiViewController: UIViewController {

    @IBOutlet weak var lblhasilkeliling: UILabel!
    @IBOutlet weak var lblhasilluas: UILabel!
    @IBOutlet weak var MasukkanSisi: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnluas(_ sender: Any) {
        let sisi : Int? = Int(MasukkanSisi.text!)
        let luas : Int = (sisi! * sisi!)
        lblhasilluas.text = "Luas dari Persegi = \(luas) m2"
    }
    @IBAction func btnkeliling(_ sender: Any) {
        let sisi : Int? = Int(MasukkanSisi.text!)
        let keliling : Int = (4 * sisi!)
        lblhasilkeliling.text = "Keliling dari Persegi = \(keliling) m2"
    }
    @IBAction func btnreset(_ sender: Any) {
        MasukkanSisi.text = ""
        lblhasilkeliling.text = ""
        lblhasilluas.text = ""
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
