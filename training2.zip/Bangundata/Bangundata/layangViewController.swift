//
//  layangViewController.swift
//  Bangundata
//
//  Created by Batsa Taqiya on 25/11/17.
//  Copyright © 2017 Batsa Taqiya. All rights reserved.
//

import UIKit

class layangViewController: UIViewController {

    @IBOutlet weak var lblhasilkeliling: UILabel!
    @IBOutlet weak var lblhasilluas: UILabel!
    @IBOutlet weak var lblmasukkansisi2: UITextField!
    @IBOutlet weak var lblmasukkansisi1: UITextField!
    @IBOutlet weak var lblmasukkanD2: UITextField!
    @IBOutlet weak var lblmasukkanD1: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func btnluas(_ sender: Any) {
        let D1 : Int? = Int(lblmasukkanD1.text!)
        let D2 : Int? = Int(lblmasukkanD2.text!)
        let luas : Int = ((D1! * D2!) / 2)
        lblhasilluas.text = "Hasil Dari Luas Layang2 = \(luas)"
    }
    
    @IBAction func btnkeliling(_ sender: Any) {
        let sisi1 : Int? = Int(lblmasukkansisi1.text!)
        let sisi2 : Int? = Int(lblmasukkansisi2.text!)
        let keliling : Int = (2 * (sisi1! + sisi2!))
        lblhasilkeliling.text = "Hasil dari keliling Layang2 = \(keliling)"
    }
    @IBAction func btnreset(_ sender: Any) {
        lblmasukkanD1.text = ""
        lblmasukkanD2.text = ""
        lblmasukkansisi1.text = ""
        lblmasukkansisi2.text = ""
        lblhasilluas.text = ""
        lblhasilkeliling.text = ""
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
