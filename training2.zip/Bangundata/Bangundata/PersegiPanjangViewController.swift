//
//  PersegiPanjangViewController.swift
//  Bangundata
//
//  Created by Batsa Taqiya on 25/11/17.
//  Copyright © 2017 Batsa Taqiya. All rights reserved.
//

import UIKit

class PersegiPanjangViewController: UIViewController {

    @IBOutlet weak var lblhasilkeliling: UILabel!
    @IBOutlet weak var lblhasilluas: UILabel!
    @IBOutlet weak var lblmasukanlebar: UITextField!
    @IBOutlet weak var lblmasukanpanjang: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func btnluas(_ sender: Any) {
        let panjang : Int? = Int(lblmasukanpanjang.text!)
        let lebar : Int? = Int(lblmasukanlebar.text!)
        let luas : Int = (panjang! * lebar!)
        lblhasilluas.text = "Luas Dari Persegi Panjang = \(luas)"
        
    }
    @IBAction func btnkeliling(_ sender: Any) {
        let panjang : Int? = Int(lblmasukanpanjang.text!)
        let lebar : Int? = Int(lblmasukanlebar.text!)
        let keliling : Int = (2 * (panjang! + lebar!))
        lblhasilkeliling.text = "Keliling Dari Persegi Panjang = \(keliling)"
    }
    @IBAction func btnreset(_ sender: Any) {
        lblmasukanpanjang.text = ""
        lblmasukanlebar.text = ""
        lblhasilkeliling.text = ""
        lblhasilluas.text = ""
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
