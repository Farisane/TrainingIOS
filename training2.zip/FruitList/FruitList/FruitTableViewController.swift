//
//  FruitTableViewController.swift
//  FruitList
//
//  Created by Batsa Taqiya on 25/11/17.
//  Copyright © 2017 Batsa Taqiya. All rights reserved.
//

import UIKit
var fruit = ["nanas","Apple","semangka"]
var desk = ["nanas mengandung banyak air","jeruk mengandung lebih banyak air dari nanas","semangka paling banyak mengandung air diantaranya"]
var myIndeks = 0

class FruitTableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
   
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return fruit.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = fruit[indexPath.row]

        // Configure the cell...

        return cell
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        myIndeks = indexPath.row
        performSegue(withIdentifier: "segue", sender: self)
    }
    
}
