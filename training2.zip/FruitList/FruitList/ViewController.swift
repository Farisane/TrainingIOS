//
//  ViewController.swift
//  FruitList
//
//  Created by Batsa Taqiya on 25/11/17.
//  Copyright © 2017 Batsa Taqiya. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lbldesk: UILabel!
    @IBOutlet weak var imagegambar: UIImageView!
    @IBOutlet weak var lbljudul: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lbljudul.text = fruit[myIndeks]
        lbldesk.text = desk[myIndeks]
        imagegambar.image = UIImage(named: fruit[myIndeks])
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

