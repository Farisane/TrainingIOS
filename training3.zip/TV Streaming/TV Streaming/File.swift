//
//  File.swift
//  TV Streaming
//
//  Created by Batsa Taqiya on 25/11/17.
//  Copyright © 2017 Batsa Taqiya. All rights reserved.
//

import UIKit
import MediaPlayer
import AVFoundation
import AVKit

class streaming: AVPlayerViewController{
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let url = URL(string:"http://119.235.249.60:1935/wesaltv/live/playlist.m3u8")
        let movieURL = url
        player = AVPlayer(url: movieURL!)
    }
}
