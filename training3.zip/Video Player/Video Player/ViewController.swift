//
//  ViewController.swift
//  Video Player
//
//  Created by Batsa Taqiya on 25/11/17.
//  Copyright © 2017 Batsa Taqiya. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation


class ViewController: UIViewController {
    var player1 = AVPlayerViewController ()
var Playerview = AVPlayer()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    override func viewDidAppear(_ animated: Bool) {
        let fileurl = NSURL(fileURLWithPath: "/Users/batsataqiya/Downloads/JANGAN PUTUS ASA - Film Pendek Inspirasi - Film pendek motivasi - Short Movie.mp4")
        Playerview = AVPlayer(url: fileurl as URL)
        player1.player = Playerview
        
        self.present(player1, animated: true){
            self.player1.player?.play()
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


