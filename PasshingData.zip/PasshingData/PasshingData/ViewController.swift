//
//  ViewController.swift
//  PasshingData
//
//  Created by Batsa Taqiya on 26/11/17.
//  Copyright © 2017 Batsa Taqiya. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var lblAddress: UITextField!
    @IBOutlet weak var lblCampus: UITextField!
    @IBOutlet weak var lblSubject: UITextField!
    @IBOutlet weak var lblBOP: UITextField!
    @IBOutlet weak var lblemail: UITextField!
    @IBOutlet weak var lblPassword: UITextField!
    @IBOutlet weak var lblUsername: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if (segue.identifier == "kirim"){
            let kirimdata = segue.destination as! DataViewController
            kirimdata.username = lblUsername.text!
            kirimdata.password1 = lblPassword.text!
            kirimdata.email1 = lblemail.text!
            kirimdata.BOP1 = lblemail.text!
            kirimdata.campus1 = lblCampus.text!
            kirimdata.subject1 = lblSubject.text!
            kirimdata.address1 = lblAddress.text!
        }
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

