//
//  DataViewController.swift
//  PasshingData
//
//  Created by Batsa Taqiya on 26/11/17.
//  Copyright © 2017 Batsa Taqiya. All rights reserved.
//

import UIKit

class DataViewController: UIViewController {

    @IBOutlet weak var address: UILabel!
    @IBOutlet weak var Campus: UILabel!
    @IBOutlet weak var subject: UILabel!
    @IBOutlet weak var BOP: UILabel!
    @IBOutlet weak var email: UILabel!
    @IBOutlet weak var password: UILabel!
    @IBOutlet weak var nama: UILabel!
    
    var username = ""
    var password1 = ""
    var email1 = ""
    var BOP1 = ""
    var subject1 = ""
    var campus1 = ""
    var address1 = ""

    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        nama.text = "His Name Is " + username
        password.text = "His Password is " + password1
        email.text = "His Email is " + email1
        BOP.text = "he was born in " + BOP1
        Campus.text = "he studies in Campus named " + campus1
        address.text = "he Lives at " + address1
        subject.text = "his Subject is " + subject1
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
