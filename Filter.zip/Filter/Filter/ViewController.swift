//
//  ViewController.swift
//  Filter
//
//  Created by 桜宮まいか on 2017/11/28.
//  Copyright © 2017年 SMK IDN. All rights reserved.
//

import UIKit
// mengambil data dari core
import MobileCoreServices
//mengambil isi gallery
import AssetsLibrary

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var imgPreview: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
      
        
    }
    @IBAction func btnsave(_ sender: Any) {
        if imgPreview.image == nil{
            //kondisi ketika kosong
            let alert = UIAlertView(title: "Caution", message: "Gambar Kosong, Masukkan gambar terlebih dahulu", delegate: nil, cancelButtonTitle: "OK")
            alert.show()
        }else{
            UIImageWriteToSavedPhotosAlbum(imgPreview.image!, self, #selector(image( _:didFinishSavingWithError:contextInfo:)), nil)
        }
        
    }
    
    @objc func image(_ image:UIImage, didFinishSavingWithError error: Error?, contextInfo: UnsafeRawPointer){
        if let error = error {
            let alert = UIAlertController(title: "Error", message: error.localizedDescription, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            present(alert, animated: true)
        }
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info:[String : Any]) {
    if let pickedImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
        custumFunction(image: pickedImage)
    }
    dismiss(animated: true, completion: nil)
}
    
    func custumFunction(image: UIImage){
        imgPreview.image = image
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func btnBrowser(_ sender: Any) {
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary){
            let imgPicker = UIImagePickerController()
            imgPicker.delegate = self as? UIImagePickerControllerDelegate & UINavigationControllerDelegate
            imgPicker.sourceType = UIImagePickerControllerSourceType.photoLibrary
            imgPicker.allowsEditing = true
            self.present(imgPicker, animated: true, completion: nil)
        }
        
    }
    
    @IBAction func btnEfekBlur(_ sender: Any) {
        if imgPreview.image == nil{
                let alert = UIAlertView(title: "Please", message: "Choose the Image",delegate: nil, cancelButtonTitle: "OK")
                alert.show()
        }else{
            let originalImage = CIImage(image: imgPreview.image!)
            let filter = CIFilter(name: "CIBoxBlur")
            filter?.setDefaults()
            filter?.setValue(originalImage, forKey: kCIInputImageKey)
            let outputImage = filter?.outputImage
            let newImage = UIImage(ciImage: outputImage!)
            imgPreview.image = newImage
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

