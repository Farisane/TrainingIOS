//
//  MapKedua.swift
//  MapkitTraining
//
//  Created by 桜宮まいか on 2017/11/27.
//  Copyright © 2017年 SMK IDN. All rights reserved.
//

import Foundation
import MapKit

class MapKedua: NSObject, MKAnnotation{
    
    var title:String?
    var coordinate:CLLocationCoordinate2D
    
    init(title: String, coordinate: CLLocationCoordinate2D){
        
        self.title = title
        self.coordinate = coordinate
    }
}
