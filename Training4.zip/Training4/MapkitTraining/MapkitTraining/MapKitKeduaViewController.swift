//
//  MapKitKeduaViewController.swift
//  MapkitTraining
//
//  Created by 桜宮まいか on 2017/11/27.
//  Copyright © 2017年 SMK IDN. All rights reserved.
//

import UIKit
import MapKit

class MapKitKeduaViewController: UIViewController {

    @IBOutlet weak var MapView: MKMapView!
    override func viewDidLoad() {
        super.viewDidLoad()

        let CandiBorobudur=MapKedua(title: "Candi Borobudur", coordinate: CLLocationCoordinate2D(latitude: -7.607874, longitude: 110.203751))
         let KetepPass=MapKedua(title: "Ketep Pass", coordinate: CLLocationCoordinate2D(latitude: -7.4945, longitude: 110.3817))
         let puthukSetumbu=MapKedua(title: "Phutuk Setumbu", coordinate: CLLocationCoordinate2D(latitude: -7.6071027, longitude: 110.1754223))
        
        MapView.addAnnotation(CandiBorobudur)
        MapView.addAnnotation(KetepPass)
        MapView.addAnnotation(puthukSetumbu)
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
