//
//  ViewController.swift
//  Radio
//
//  Created by 桜宮まいか on 2017/11/27.
//  Copyright © 2017年 SMK IDN. All rights reserved.
//

import UIKit
import AVKit
import MediaPlayer

class ViewController: UIViewController {
    
    @IBOutlet weak var lbldetail: UILabel!
    @IBOutlet weak var lblplay: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @IBAction func btnplay(_ sender: Any) {
        toggleButtonRadio()
    }
    
    func toggleButtonRadio(){
        if radiofunction.sharedInstance.currentPlaying(){
            pauseRadio()
        }else{
            playRadio()
        }
    }
    func pauseRadio(){
        radiofunction.sharedInstance.pause()
        lbldetail.text = "Play Radio"
        lblplay.setImage(UIImage(named: "play.png"), for: .normal)
    }
    
    func playRadio(){
        radiofunction.sharedInstance.play()
        lbldetail.text = "Pause Radio"
        lblplay.setImage(UIImage(named: "pause.png"), for: .normal)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

