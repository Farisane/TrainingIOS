//
//  radiofunction.swift
//  Radio
//
//  Created by 桜宮まいか on 2017/11/27.
//  Copyright © 2017年 SMK IDN. All rights reserved.
//

import Foundation
//tambahkan library
import AVFoundation

//nama class harus sama dengan nama swift class
class radiofunction{
    static let sharedInstance = radiofunction()
    private var isPlaying = false
    
    private var player = AVPlayer(url: (NSURL(string: "http://162.243.130.87/")! as URL))
    
    func play(){
        player.play()
        isPlaying = true
    }
    func pause(){
        player.pause()
        isPlaying = false
    }
    func toogleButton(){
        if isPlaying{
            pause()
        }else{
            play()
        }
        
    }
    func currentPlaying() -> Bool{
        return isPlaying
    }
}

