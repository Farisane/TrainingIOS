//
//  FirstViewController.swift
//  Custum Tab Bar
//
//  Created by 桜宮まいか on 2017/11/27.
//  Copyright © 2017年 SMK IDN. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
//        let color1 = UIColor.cyan
        let color2 = UIColor.green
        
        //deklarasi tabbar
        //tint color
        let tabbar = self.tabBarController?.tabBar
        tabbar?.tintColor = UIColor.black
        
        //bar tint
        tabbar?.barTintColor = color2
        //tabbar gak diklik
        tabbar?.unselectedItemTintColor = UIColor.white
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

