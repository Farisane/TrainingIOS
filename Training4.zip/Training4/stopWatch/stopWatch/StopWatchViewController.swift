//
//  StopWatchViewController.swift
//  stopWatch
//
//  Created by 桜宮まいか on 2017/11/27.
//  Copyright © 2017年 SMK IDN. All rights reserved.
//

import UIKit

class StopWatchViewController: UIViewController {

    var counter = 0.0
    var timer = Timer()
    
    var isPlaying = false
    
    @IBOutlet weak var lbltime: UILabel!
    @IBOutlet weak var lblpause: UIButton!
    @IBOutlet weak var lblreset: UIButton!
    @IBOutlet weak var lblplay: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        lbltime.text = String(counter)
        lblpause.isEnabled = false
        
        
        // Do any additional setup after loading the view.
    }

    @IBAction func btnplay(_ sender: Any) {
        
        if(isPlaying){
            return
        }
        lblplay.isEnabled = false
        lblpause.isEnabled = true
        
        timer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(UpdateTimer), userInfo: nil, repeats: true)
    
    isPlaying = true
        
    }
    
    @objc func UpdateTimer(){
        counter = counter + 0.1
        lbltime.text = String(format: "%.1f", counter)
    }
    
    @IBAction func btnpause(_ sender: Any) {
        
        lblplay.isEnabled = true
        lblpause.isEnabled = false
        
        timer.invalidate()
        isPlaying = false
        
    }
    @IBAction func btnreset(_ sender: Any) {
        lblplay.isEnabled = true
        lblpause.isEnabled = false
        
        timer.invalidate()
        isPlaying = false
        
        counter = 0.0
        lbltime.text = String(counter)
        
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
